package ru.iteco.fmhandroid.dto

data class JwtResponse(
    val code: String,
    val message: String
)
