package ru.iteco.fmhandroid.dto

data class RefreshRequest(
    val refreshToken: String
)
