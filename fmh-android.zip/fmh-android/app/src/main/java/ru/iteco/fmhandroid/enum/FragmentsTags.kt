package ru.iteco.fmhandroid.enum

enum class FragmentsTags {
    NEWS_LIST_FRAGMENT,
    NEWS_CONTROL_PANEL_FRAGMENT
}
